import React from 'react';
import axios from 'axios';

export class AddTodo extends React.Component {
	/*componentWillMount() {
		axios.get("")
		.then((data)=> {
			this.setState({list: data.list})
		})
	}*/
	render() {
		return (
			<div>
				<input type="text" ref="input"/>
				<button onClick={this.handleClick.bind(this)}>Add todo</button>
			</div>
		)
	}
	handleClick(event) {
		const text = this.refs.input.value;
		this.props.onAddClick(text);
	}
}