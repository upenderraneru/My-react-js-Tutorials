import React from 'react';
import {AddTodo} from './AddTodo';
import {TodoList} from './TodoList';
import {Footer} from './Footer';
import {SET_VISIBILITY_FILTER, Filters} from '../constants/filters';


let nextTodoId = 0;

const ADD_TODO='ADD_TODO',TOGGLE_TODO='TOGGLE_TODO';



export function TodoApp(props) {
	let visibleTodos = props.todos;
	console.log(props.todos);
	switch(props.visibilityFilter) {
		case Filters.SHOW_COMPLETED: 
			visibleTodos = props.todos.filter(function(item){
				return item.completed;
			});
			break;
		case Filters.SHOW_ACTIVE: 
			visibleTodos = props.todos.filter(function(item){
				return !item.completed;
			});
			break;
	}

	function onToDoClick(id) {
		props.dispatch({
			type:TOGGLE_TODO,
			id:id
		})
	}
	function onAddClick(text) {
		props.dispatch({
			type: ADD_TODO,
			id : nextTodoId++,
			text
		})
	}

	function onFilterChange(filter) {
		props.dispatch({
			type : SET_VISIBILITY_FILTER,
			filter
		})
	}
	// props
		// state
			// todos : []
	return (
		<div>
			<AddTodo 
				onAddClick={onAddClick}
			/>
			<TodoList 
				todos={visibleTodos} 
				onToDoClick={onToDoClick}
			/>
			<Footer 
				filter={props.visibilityFilter}
				onFilterChange={onFilterChange}
			/>
		</div>
	);
}