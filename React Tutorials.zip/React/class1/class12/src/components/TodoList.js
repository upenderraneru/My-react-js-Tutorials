import React from 'react';
import {Todo} from './Todo'

export const TodoList = ({todos, onToDoClick}) =>  (
		<ul>
			{todos.map(function(item){
				return <Todo {...item} key={item.id} onClick={()=>onToDoClick(item.id)}/>
			})}
		</ul>
	);