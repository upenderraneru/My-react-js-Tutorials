import React from 'react';

export const FilterLink = ({onClick, isActive, name}) => {
	function onClickHandler(event) {
		event.preventDefault();
		onClick();
	}

	if(isActive) {
		return <span>{name}</span>
	}

	return (
		<a href="#" onClick={onClickHandler}> {name}</a>
	)
}