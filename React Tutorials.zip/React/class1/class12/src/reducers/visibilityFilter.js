import React from 'react';
import {SET_VISIBILITY_FILTER, Filters} from '../constants/filters';

export const visibilityFilter = (state=Filters.SHOW_ALL, action) => {
	switch(action.type) {
		case SET_VISIBILITY_FILTER :
			return action.filter;
		default :
			return state;
	}
}