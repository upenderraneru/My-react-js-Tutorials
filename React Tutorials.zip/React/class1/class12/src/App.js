import React from 'react';
import ReactDOM from 'react-dom';
import {TodoApp} from './components/TodoApp';
import Redux, {combineReducers, createStore, applyMiddleware} from 'redux';
import {todos} from './reducers/todos';
import {visibilityFilter} from './reducers/visibilityFilter';
import axios from 'axios';
import ReactRedux from 'react-redux';
import ReduxThunk from 'redux-thunk';
import {SET_VISIBILITY_FILTER, Filters} from './constants/filters';

const todoAppReducers = combineReducers({
	visibilityFilter, 
	todos
});
const store = createStore(todoAppReducers, applyMiddleware(ReduxThunk));

// if there any changes in state of the store
// .subscribe

function dispatch(action) {
	console.log('-----------');
	console.log('previous state : ', store.getState());
	console.log('dispatching action : ', action);
	// 
	store.dispatch(action);
	console.log('next state : ', store.getState());
}
function render() {

	ReactDOM.render(

		<TodoApp 
			{...store.getState()}
			dispatch={dispatch}
		/>, document.getElementById('app'))
}
render();

store.subscribe(render);
console.log('initial state', store.getState())

var obj = {
	name : 'pandiri',
	func1 : function() {
		console.log(this);
		const func2 = () => {
			console.log(this)
		}
		func2();
	} 
}

/*function Person(name, age){
	this.name = name;
	this.age = age;
}
var p1 = new Person('anudeep', 24)
var p2 = new Person('andy', 25)
console.log(p1,p2)
*/

