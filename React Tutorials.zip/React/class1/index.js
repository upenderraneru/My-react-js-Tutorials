import React from 'react';
import ReactDOM from 'react-dom';

class Hello extends React.Component { 
	render() {
		return  (
			<div>
				<h1>Hello World</h1>
				<div>This content</div>
			</div>
		)
	}
}

/*
var Hello = React.createClass({
	render : function() {
		return React.createElement('h1',{}, 'Hello World')
	} 
})
*/

ReactDOM.render(<Hello />, document.getElementById('app'))
//ReactDOM.render(React.createElement(Hello), document.getElementById('app'))
