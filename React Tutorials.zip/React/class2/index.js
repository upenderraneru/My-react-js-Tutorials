import React from 'react';
import ReactDOM from 'react-dom';
import { Hello } from './Hello';
import {App} from './App';

ReactDOM.render(<App />, document.getElementById('app'))
