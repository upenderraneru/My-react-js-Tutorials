import React from 'react';

/*export class Widget extends React.Component {
	render() {
		return (
			<div>the message received from props is : {this.props.msg}</div>
		)
	}
} */

/* dumb component, functional component, stateless component
	--> no state
	--> no react component life cycle methods
	--> we only have props
	--> JSX would there 
*/
export function Widget(props) {
	return (
		<div>the message received from props is : {props.msg}</div>
	)
}