import React from 'react';
import {Widget} from './Widget';



/*
	stateful component, smart component, class component
	-- when we need state
	-- when we use life cycle methods

	-- we also have access to props 
*/
export class App extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			message : 'default state value'
		};
		this.update = this.update.bind(this);
	}

	update(event) {
		var inpMsg = event.target.value;
		this.setState(function(prevState, props){
			return {message: inpMsg};
		})
	}

	render() {
		return (
			<div>
				<h1>This is app component</h1>
				<div> The following are Widget component </div>
				<input type="text" onKeyUp={this.update}/>
				<Widget msg={this.state.message} />
				<Widget msg={this.state.message} />
				<Widget msg={this.state.message} />
				<Widget msg={this.state.message} />
				<Widget msg={this.state.message} />
			</div>
		)
	}

}